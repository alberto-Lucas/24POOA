﻿
namespace PessoaPOO
{
    partial class frmExibeUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtExibeIdade = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtExibeDtNascimento = new System.Windows.Forms.TextBox();
            this.txtExibeSenha = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtExibeEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtExibeNome = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtExibeCPF = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtExibeIdade
            // 
            this.txtExibeIdade.Location = new System.Drawing.Point(518, 27);
            this.txtExibeIdade.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExibeIdade.Name = "txtExibeIdade";
            this.txtExibeIdade.ReadOnly = true;
            this.txtExibeIdade.Size = new System.Drawing.Size(57, 20);
            this.txtExibeIdade.TabIndex = 64;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(518, 11);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 63;
            this.label12.Text = "Idade";
            // 
            // txtExibeDtNascimento
            // 
            this.txtExibeDtNascimento.Location = new System.Drawing.Point(416, 27);
            this.txtExibeDtNascimento.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExibeDtNascimento.Name = "txtExibeDtNascimento";
            this.txtExibeDtNascimento.ReadOnly = true;
            this.txtExibeDtNascimento.Size = new System.Drawing.Size(98, 20);
            this.txtExibeDtNascimento.TabIndex = 62;
            // 
            // txtExibeSenha
            // 
            this.txtExibeSenha.Location = new System.Drawing.Point(306, 75);
            this.txtExibeSenha.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExibeSenha.Name = "txtExibeSenha";
            this.txtExibeSenha.ReadOnly = true;
            this.txtExibeSenha.Size = new System.Drawing.Size(208, 20);
            this.txtExibeSenha.TabIndex = 61;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(306, 58);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 60;
            this.label7.Text = "Senha:";
            // 
            // txtExibeEmail
            // 
            this.txtExibeEmail.Location = new System.Drawing.Point(9, 75);
            this.txtExibeEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExibeEmail.Name = "txtExibeEmail";
            this.txtExibeEmail.ReadOnly = true;
            this.txtExibeEmail.Size = new System.Drawing.Size(294, 20);
            this.txtExibeEmail.TabIndex = 59;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 58);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 58;
            this.label8.Text = "Email:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(416, 11);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 13);
            this.label9.TabIndex = 57;
            this.label9.Text = "Data Nascimento";
            // 
            // txtExibeNome
            // 
            this.txtExibeNome.Location = new System.Drawing.Point(119, 27);
            this.txtExibeNome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExibeNome.Name = "txtExibeNome";
            this.txtExibeNome.ReadOnly = true;
            this.txtExibeNome.Size = new System.Drawing.Size(294, 20);
            this.txtExibeNome.TabIndex = 56;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(119, 11);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 55;
            this.label10.Text = "Nome:";
            // 
            // txtExibeCPF
            // 
            this.txtExibeCPF.Location = new System.Drawing.Point(9, 27);
            this.txtExibeCPF.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtExibeCPF.Name = "txtExibeCPF";
            this.txtExibeCPF.ReadOnly = true;
            this.txtExibeCPF.Size = new System.Drawing.Size(107, 20);
            this.txtExibeCPF.TabIndex = 54;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 11);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 53;
            this.label11.Text = "CPF:";
            // 
            // frmExibeUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 108);
            this.Controls.Add(this.txtExibeIdade);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtExibeDtNascimento);
            this.Controls.Add(this.txtExibeSenha);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtExibeEmail);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtExibeNome);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtExibeCPF);
            this.Controls.Add(this.label11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmExibeUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Visualizar Usuário";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtExibeIdade;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtExibeDtNascimento;
        private System.Windows.Forms.TextBox txtExibeSenha;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtExibeEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtExibeNome;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtExibeCPF;
        private System.Windows.Forms.Label label11;
    }
}